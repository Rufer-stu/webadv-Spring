package webadv.s99201105.p02;

import java.awt.print.Printable;
import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.Scanner;

import org.apache.commons.codec.digest.DigestUtils;

public class Main {
	private static Hashtable<String, String> usernamePasswordMap;
	
	 @SuppressWarnings("resource")
	public static void main(String[] args) {

		 try {
	            usernamePasswordMap = new Hashtable<String,String>();
	            File file = new File("password.txt");
	            Scanner scanner = new Scanner(new FileInputStream("password.txt"));
	            boolean isPasswordLine = false;
	            String username = null, password;
	            while (scanner.hasNextLine()) {
	                if (!isPasswordLine) {
	                    username = scanner.nextLine();
	                }
	                else {
	                    password = scanner.nextLine();
	                    usernamePasswordMap.put(username, password);
	                }
	                isPasswordLine = !isPasswordLine;
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		 Scanner scanner = new Scanner(System.in);
		 System.out.print("请输入账号：");
		 String userName = scanner.nextLine();
		 System.out.print("请输入密码：");
		 String password = scanner.nextLine();
		 String digest = DigestUtils.sha256Hex(password);//SHA-256算法保护
		 if (usernamePasswordMap.get(userName).equals(digest)) {
             System.out.println("Login success.");
             
         }
         else {
             System.out.println("something wrong in username or password.");
         }
		 
	 }
	 public static String sha256hex(String input) {
	        return DigestUtils.sha256Hex(input);
	    }
}
